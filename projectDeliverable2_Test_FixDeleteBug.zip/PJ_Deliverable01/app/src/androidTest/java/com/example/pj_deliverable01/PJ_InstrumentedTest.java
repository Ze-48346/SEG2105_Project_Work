package com.example.pj_deliverable01;

import android.content.Context;

import androidx.test.core.app.ApplicationProvider;
import androidx.test.platform.app.InstrumentationRegistry;
import androidx.test.ext.junit.runners.AndroidJUnit4;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

import java.io.IOException;

import static org.junit.Assert.*;

/**
 * Instrumented test, which will execute on an Android device.
 *
 * @see <a href="http://d.android.com/tools/testing">Testing documentation</a>
 */
@RunWith(AndroidJUnit4.class)
public class PJ_InstrumentedTest {
    private MyDBHandler db;

    @Before
    public void createDB(){
        Context context = ApplicationProvider.getApplicationContext();
        db = new MyDBHandler(context);
    }

    @After
    public void closeDB() throws IOException {
        db.close();
    }

    @Test
    public void test1_DatabaseExistence() {
        assertNotNull(db);
    }

    @Test
    public void test2_AddStudent() {
        // Context of the app under test.
//        Context appContext = InstrumentationRegistry.getInstrumentation().getTargetContext();
//        assertEquals("com.example.pj_deliverable01", appContext.getPackageName());
//        MyDBHandler db = new MyDBHandler(appContext);
        String studentID = "001";
        String studentName = "James";
        String studentPassWord = "111222";
        Student student = new Student(studentID,studentName,studentPassWord);

        db.addStudent(student);
        Student findStudent = db.findStudent(studentID);

        boolean result = true;
        if (findStudent == null){
            result = false;
        }
        assertTrue(result);
    }

    @Test
    public void test3_findStudent() {

        String notExistStudentID = "9999999";
        Student findStudent = db.findStudent(notExistStudentID);

        boolean result = true;
        if (findStudent == null){
            result = false;
        }
        assertFalse(result);
    }

    @Test
    public void test4_addInstructor() {

        String instructorID = "001";
        String instructorName = "Patrick";
        String instructorPassWord = "333444";
        Instructor instructor = new Instructor(instructorID,instructorName,instructorPassWord);

        db.addInstructor(instructor);
        Instructor findInstructor = db.findInstructor(instructorID);

        boolean result = true;
        if (findInstructor == null){
            result = false;
        }
        assertTrue(result);
    }

    @Test
    public void test5_findInstructor() {

        String notExistStudentID = "00000000";
        Instructor findInstructor = db.findInstructor(notExistStudentID);

        boolean result = true;
        if (findInstructor == null){
            result = false;
        }
        assertFalse(result);
    }

    @Test
    public void test6_deleteStudent() {

        String studentID = "002";
        String studentName = "Helen";
        String studentPassWord = "111222";
        Student student = new Student(studentID,studentName,studentPassWord);
        db.addStudent(student);
        Student findResult = db.findStudent(studentID);
        assertNotNull(findResult); //First assert

        db.deleteStudent(studentID);
        Student deleteResult = db.findStudent(studentID);
        boolean result = false;
        if (deleteResult == null){
            result = true;
        }
        assertTrue(result);     //Last assert
    }

    @Test
    public void test7_deleteInstructor() {

        String instructorID = "002";
        String instructorName = "Patrick";
        String instructorPassWord = "111222";
        Instructor instructor = new Instructor(instructorID,instructorName,instructorPassWord);
        db.addInstructor(instructor);
        Instructor findResult = db.findInstructor(instructorID);
        assertNotNull(findResult); //First asset

        db.deleteInstructor(instructorID);
        Instructor deleteResult = db.findInstructor(instructorID);
        boolean result = false;
        if (deleteResult == null){
            result = true;
        }
        assertTrue(result);     //Last asset
    }



}