package com.example.pj_deliverable01;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class MyDBHandler extends SQLiteOpenHelper {
    private static final int DATABSE_VERSION = 1;
    private static final String DATABASE_NAME = "SEG2105_Project.db";

    // Student //
    private static final String TABLE_STUDENT = "Student";
    private static final String STUDENT_ID = "Student_ID";
    private static final String STUDENT_NAME = "Student_Name";
    private static final String STUDENT_PASSWORD = "Student_PassWord";
    // Student //

    // Instructor //
    private static final String TABLE_INSTRUCTOR = "Instructor";
    private static final String INSTRUCTOR_ID = "Instructor_ID";
    private static final String INSTRUCTOR_NAME = "Instructor_Name";
    private static final String INSTRUCTOR_PASSWORD = "Instructor_PassWord";
    // Instructor //

    // Course //
    private static final String TABLE_COURSE="Course";
    private static final String COLUMN_ID="ID";
    private static final String COLUMN_COURSENAME="Course_Name";
    private static final String COLUMN_COURSECODE="Course_Code";
    // Course //

    public MyDBHandler(Context context){
        super(context, DATABASE_NAME,null,DATABSE_VERSION);
    }

    public void onCreate(SQLiteDatabase db){
        String TableStudent = "CREATE TABLE " + TABLE_STUDENT + "(" +
                STUDENT_ID + " TEXT PRIMARY KEY," +
                STUDENT_NAME + " TEXT," +
                STUDENT_PASSWORD + " TEXT" + ")";

        String TableInstructor = "CREATE TABLE " + TABLE_INSTRUCTOR + "(" +
                INSTRUCTOR_ID + " TEXT PRIMARY KEY," +
                INSTRUCTOR_NAME + " TEXT," +
                INSTRUCTOR_PASSWORD + " TEXT" + ")";

        String CreateCourseTable = "CREATE TABLE " + TABLE_COURSE + "(" +
                COLUMN_ID + " INTEGER PRIMARY KEY, "+
                COLUMN_COURSECODE +" TEXT," +
                COLUMN_COURSENAME + " TEXT" + ")";


        db.execSQL(TableStudent);
        db.execSQL(TableInstructor);
        db.execSQL(CreateCourseTable);
    }

    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion){
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_STUDENT);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_INSTRUCTOR);
        db.execSQL("DROP TABLE IF EXISTS "+ TABLE_COURSE);
        onCreate(db);
    }

    public void addStudent(Student student){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues studentInfo = new ContentValues();
        studentInfo.put(STUDENT_ID, student.getID());
        studentInfo.put(STUDENT_NAME, student.getName());
        studentInfo.put(STUDENT_PASSWORD, student.getPassWord());
        db.insert(TABLE_STUDENT, null, studentInfo);
//        db.close();
    }


    // Student------------------------------------ //
    public Student findStudent(String studentID){
        SQLiteDatabase db = this.getWritableDatabase();

        String query = "SELECT * FROM " + TABLE_STUDENT + " WHERE " + STUDENT_ID + " = \"" + studentID + "\"";
        Cursor cursor = db.rawQuery(query, null);

        Student student = new Student();
        if(cursor.moveToFirst()){
            student.setID(cursor.getString(0));
            student.setName(cursor.getString(1));
            student.setPassWord(cursor.getString(2));
        } else{
            student = null;
        }
//        db.close();
        return student;
    }

    public ArrayList<Student>  findAllStudent(){
        SQLiteDatabase db = this.getWritableDatabase();
        ArrayList<Student> allStudentList = new ArrayList<Student>();

        String query = "SELECT * FROM " + TABLE_STUDENT;
        Cursor cursor = db.rawQuery(query, null);


        while(cursor.moveToNext()){
            Student student = new Student();
            student.setID(cursor.getString(0));
            student.setName(cursor.getString(1));
            student.setPassWord(cursor.getString(2));
            allStudentList.add(student);
        }
//        db.close();
        return allStudentList;
    }

    public boolean deleteStudent(String studentID){
        boolean result = false;
        SQLiteDatabase db = this.getWritableDatabase();

        String query = "SELECT * FROM " + TABLE_STUDENT + " WHERE  " + STUDENT_ID + " = \""
                + studentID + "\"";
        Cursor cursor = db.rawQuery(query,null);
        if(cursor.moveToFirst()){
            String idStr = cursor.getString(0);
            String [] idArg = { idStr };
            db.delete(TABLE_STUDENT, STUDENT_ID + " = ?",idArg);
            cursor.close();
            result =true;
        }
        return result;
    }
    // Student------------------------------------ //

    // Instructor------------------------------------ //
    public void addInstructor(Instructor instructor){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues instructorInfo = new ContentValues();
        instructorInfo.put(INSTRUCTOR_ID, instructor.getID());
        instructorInfo.put(INSTRUCTOR_NAME, instructor.getName());
        instructorInfo.put(INSTRUCTOR_PASSWORD, instructor.getPassWord());
        db.insert(TABLE_INSTRUCTOR, null, instructorInfo);
//        db.close();
    }

    public Instructor findInstructor(String instructorID){
        SQLiteDatabase db = this.getWritableDatabase();

        String query = "SELECT * FROM " + TABLE_INSTRUCTOR + " WHERE " + INSTRUCTOR_ID + " = \"" + instructorID + "\"";
        Cursor cursor = db.rawQuery(query, null);

        Instructor instructor = new Instructor();
        if(cursor.moveToFirst()){
            instructor.setID(cursor.getString(0));
            instructor.setName(cursor.getString(1));
            instructor.setPassWord(cursor.getString(2));
        } else{
            instructor = null;
        }
//        db.close();
        return instructor;
    }

    public ArrayList<Instructor>  findAllInstructor(){
        SQLiteDatabase db = this.getWritableDatabase();
        ArrayList<Instructor> allInstructorList = new ArrayList<Instructor>();

        String query = "SELECT * FROM " + TABLE_INSTRUCTOR;
        Cursor cursor = db.rawQuery(query, null);

        while(cursor.moveToNext()){
            Instructor instructor = new Instructor();
            instructor.setID(cursor.getString(0));
            instructor.setName(cursor.getString(1));
            instructor.setPassWord(cursor.getString(2));
            allInstructorList.add(instructor);
        }
//        db.close();
        return allInstructorList;
    }

    public boolean deleteInstructor(String instructorID){
        boolean result = false;
        SQLiteDatabase db = this.getWritableDatabase();

        String query = "SELECT * FROM " + TABLE_INSTRUCTOR + " WHERE  " + INSTRUCTOR_ID + " = \""
                + instructorID + "\"";
        Cursor cursor = db.rawQuery(query,null);
        if(cursor.moveToFirst()){
            String idStr = cursor.getString(0);
            String [] idArg = { idStr };
            db.delete(TABLE_INSTRUCTOR, INSTRUCTOR_ID + " = ?",idArg);
            cursor.close();
            result =true;
        }
        return result;
    }
    // Instructor------------------------------------ //

    // Course------------------------------------ //
    public void createCourse(Course course){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_COURSECODE, course.get_CourseCode());
        values.put(COLUMN_COURSENAME, course.get_CourseName());
        db.insert(TABLE_COURSE,null,values);
//        db.close();
    }

    public boolean deleteCourse(String courseCode){
        boolean result = false;
        SQLiteDatabase db = this.getWritableDatabase();
        String query = "SELECT * FROM "+ TABLE_COURSE +" WHERE "+ COLUMN_COURSECODE +" = \""+ courseCode + "\"";
        Cursor cursor =db.rawQuery(query,null);
        if(cursor.moveToFirst()){
            String idStr = cursor.getString(0);
            db.delete(TABLE_COURSE,COLUMN_ID+" = "+idStr,null);
            cursor.close();
            result=true;

        }
//        db.close();
        return result;
    }



    public List<Course> viewAllCourse(){
        SQLiteDatabase db = this.getWritableDatabase();
        List<Course> returnList = new ArrayList<>();
        String queryString = "SELECT * FROM " + TABLE_COURSE;

        @SuppressLint("Recycle") Cursor cursor = db.rawQuery(queryString,null);

        while (cursor.moveToNext()){
            String CourseName= cursor.getString(1);
            String CourseCode  = cursor.getString(2);
            Course course = new Course(CourseName,CourseCode);
            returnList.add(course);
        }
        cursor.close();
//        db.close();
        return returnList;
    }

    public void UpgradeCode(Course course){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values =new ContentValues();
        values.put(COLUMN_COURSECODE, course.get_CourseCode());
        String query = " SELECT * FROM "+ TABLE_COURSE +" WHERE "+ COLUMN_COURSENAME +" = \""+ course.get_CourseName() + "\"";
        Cursor cursor =db.rawQuery(query,null);
        if(cursor.moveToFirst()){
            String idStr = cursor.getString(0);
            db.update(TABLE_COURSE, values,COLUMN_ID+" = "+ idStr,null);
            cursor.close();
        }
//        db.close();
    }

    public void UpgradeName(Course course){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values =new ContentValues();
        values.put(COLUMN_COURSENAME,course.get_CourseName());
        String courseCode= course.get_CourseCode();
        String query = " SELECT * FROM "+ TABLE_COURSE +" WHERE "+ COLUMN_COURSECODE +" = \""+ courseCode + "\"";
        Cursor cursor =db.rawQuery(query,null);
        if(cursor.moveToFirst()){
            String idStr = cursor.getString(0);
            db.update( TABLE_COURSE, values,COLUMN_ID +" = "+ idStr,null);
            cursor.close();
        }db.close();
    }
    // Course------------------------------------ //

}

