package com.example.pj_deliverable01;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import com.google.android.material.textfield.TextInputLayout;

import android.os.Bundle;

public class Instructor_MainMenu extends AppCompatActivity {
    private TextView tvWelcomeText;
    private String instructor_name;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_instructor_main_menu);

        tvWelcomeText = findViewById(R.id.tvInsWelcomeText);
        instructor_name = getIntent().getStringExtra("instructorName");
        tvWelcomeText.setText("Welcome Instructor " + instructor_name + "!");
    }
}