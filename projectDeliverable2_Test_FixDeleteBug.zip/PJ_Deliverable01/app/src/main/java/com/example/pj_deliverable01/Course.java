package com.example.pj_deliverable01;

public class Course {
    private String _CourseCode;
    private String _CourseName;
    private int _ID;

    public Course(){
    }
    public Course(String CourseCode, String CourseName){
        _CourseCode = CourseCode;
        _CourseName = CourseName;

    }
    public Course(int ID, String CourseCode,String CourseName){
        _ID = ID;
        _CourseCode=CourseCode;
        _CourseCode=CourseName;
    }
    public  void  set_ID(int ID){_ID= ID;}
    public  int get_ID(int ID){return ID;}
    public void set_CourseCode(String CourseCode){
        _CourseCode= CourseCode;
    }
    public String get_CourseCode(){
        return _CourseCode;
    }
    public void  set_CourseName(String CourseName){
        _CourseName=CourseName;
    }
    public String get_CourseName(){
        return _CourseName;
    }


}
