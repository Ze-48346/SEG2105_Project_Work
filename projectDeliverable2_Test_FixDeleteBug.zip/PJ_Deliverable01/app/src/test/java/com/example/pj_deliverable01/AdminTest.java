package com.example.pj_deliverable01;

import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;
import com.example.pj_deliverable01.*;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.system.StructUtsname;

import androidx.appcompat.app.AppCompatActivity;

public class AdminTest {

    @Test
    public void testAddStudentToTable() {

    }
}
