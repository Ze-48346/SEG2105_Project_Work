package com.example.projectdeliverable1;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class CourseDBHelper extends SQLiteOpenHelper {

    private static final int DATABASE_VERSION=1;
    private static final String DATABASE_NAME="courseDB.db";
    private static final String TABLE_COURSES="courses";
    private static final String COLUMN_ID="ID";
    private static final String COLUMN_COURSENAME="courseName";
    private static final String COLUMN_COURSECODE="courseCode";
    public CourseDBHelper(Context context) {
        super(context, DATABASE_NAME, null,DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String CREATE_PRODUCTS_TABLE="CREATE TABLE "+ TABLE_COURSES + "(" +  COLUMN_ID +" INTEGER PRIMARY KEY, "+ COLUMN_COURSECODE +" TEXT," + COLUMN_COURSENAME + " TEXT" + ")";
        db.execSQL(CREATE_PRODUCTS_TABLE);

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS "+ TABLE_COURSES);
        onCreate(db);

    }
    public void createCourse(Course course){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_COURSECODE, course.get_CourseCode());
        values.put(COLUMN_COURSENAME, course.get_CourseName());
        db.insert(TABLE_COURSES,null,values);
        db.close();
    }
    public boolean deleteCourse(String courseCode){
        boolean result = false;
        SQLiteDatabase db = this.getWritableDatabase();
        String query = " SELECT * FROM "+ TABLE_COURSES +" WHERE "+ COLUMN_COURSECODE +" = \""+ courseCode + "\"";
        Cursor cursor =db.rawQuery(query,null);
        if(cursor.moveToFirst()){
            String idStr = cursor.getString(0);
            db.delete(TABLE_COURSES,COLUMN_ID+" = "+idStr,null);
            cursor.close();
            result=true;

        }db.close();
        return result;
    }
    public List<Course> viewALlCourse(){
        SQLiteDatabase db = this.getReadableDatabase();
        List<Course> returnList = new ArrayList<>();
        String queryString = " SELECT * FROM " + TABLE_COURSES;


        @SuppressLint("Recycle") Cursor cursor = db.rawQuery(queryString,null);

        if(cursor.moveToFirst()){
            while (cursor.moveToNext()){
                String CourseName= cursor.getString(1);
                String CourseCode  = cursor.getString(2);
                Course course = new Course(CourseName,CourseCode);
                returnList.add(course);

            }

        }
        cursor.close();

        db.close();


        return returnList;
    }
    public void UpgradeCode(Course course){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values =new ContentValues();
        values.put(COLUMN_COURSECODE, course.get_CourseCode());
        String query = " SELECT * FROM "+ TABLE_COURSES +" WHERE "+ COLUMN_COURSENAME +" = \""+ course.get_CourseName() + "\"";
        Cursor cursor =db.rawQuery(query,null);
        if(cursor.moveToFirst()){
            String idStr = cursor.getString(0);

            db.update(TABLE_COURSES, values,COLUMN_ID+" = "+ idStr,null);
            cursor.close();




        }db.close();


    }public void UpgradeName(Course course){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values =new ContentValues();
        values.put(COLUMN_COURSENAME,course.get_CourseName());
        String courseCode= course.get_CourseCode();
        String query = " SELECT * FROM "+ TABLE_COURSES +" WHERE "+ COLUMN_COURSECODE +" = \""+ courseCode + "\"";
        Cursor cursor =db.rawQuery(query,null);
        if(cursor.moveToFirst()){
            String idStr = cursor.getString(0);

            db.update( TABLE_COURSES, values,COLUMN_ID +" = "+ idStr,null);
            cursor.close();



        }db.close();


    }

}
