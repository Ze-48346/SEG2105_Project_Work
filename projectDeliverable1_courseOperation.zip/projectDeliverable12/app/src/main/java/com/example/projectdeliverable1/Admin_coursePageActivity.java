package com.example.projectdeliverable1;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.view.menu.MenuView;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.List;

public class Admin_coursePageActivity extends AppCompatActivity {
    RecyclerView CourseList;
    EditText CourseName;
    EditText CourseCode;
    Button ViewAll;
    Button Return;
    Button Create;
    Button Remove;
    Button UpgradeCourseName;
    Button UpgradeCourseCode;
    CourseDBHelper dbHandler;
    CourseAdapter courseAdapter;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.admin_course_page_activity);

        CourseList =findViewById(R.id.CourseList);
        CourseName = findViewById(R.id.CourseName);
        CourseCode = findViewById(R.id.CourseCode);
        ViewAll = findViewById(R.id.ViewAll);
        Return  = findViewById(R.id.Return);
        Create = findViewById(R.id.Create);
        Remove = findViewById(R.id.Remove);
        UpgradeCourseCode = findViewById(R.id.UpgradeCourseCode);
        UpgradeCourseName = findViewById(R.id.UpgradeCourseName);
        dbHandler = new CourseDBHelper(Admin_coursePageActivity.this);
        courseAdapter = new CourseAdapter(Admin_coursePageActivity.this,dbHandler.viewALlCourse());
        CourseList.setAdapter(courseAdapter);


        Create.setOnClickListener(v -> {
            dbHandler = new CourseDBHelper(Admin_coursePageActivity.this);

            String courseName= CourseName.getText().toString();
            String courseCode = CourseCode.getText().toString();
            if (courseName.equals("") || courseCode.equals("")){
                Toast.makeText(Admin_coursePageActivity.this,"You can't create a course without a name and a code",Toast.LENGTH_SHORT).show();
            }else{
            Course course = new Course(courseCode,courseName);
            dbHandler.createCourse(course);
                Toast.makeText(Admin_coursePageActivity.this,"Created Successfully",Toast.LENGTH_SHORT).show();


            }
            CourseName.setText("");
            CourseCode.setText("");
            courseAdapter = new CourseAdapter(Admin_coursePageActivity.this,dbHandler.viewALlCourse());
            CourseList.setAdapter(courseAdapter);

        });
        Remove.setOnClickListener(v -> {
            dbHandler = new CourseDBHelper(Admin_coursePageActivity.this);

            boolean result = dbHandler.deleteCourse(CourseCode.getText().toString());

            if (result) {
                CourseCode.setText("");
                CourseName.setText("");
                Toast.makeText(Admin_coursePageActivity.this,"Deleted Successfully",Toast.LENGTH_SHORT).show();

            } else {
                courseAdapter = new CourseAdapter(Admin_coursePageActivity.this,dbHandler.viewALlCourse());
                CourseList.setAdapter(courseAdapter);
                Toast.makeText(Admin_coursePageActivity.this,"No match found",Toast.LENGTH_SHORT).show();



            }

        });
        ViewAll.setOnClickListener(v -> {
            dbHandler = new CourseDBHelper(Admin_coursePageActivity.this);

            List<Course> AllCourse = dbHandler.viewALlCourse();
            LinearLayoutManager linearLayoutManger = new LinearLayoutManager(Admin_coursePageActivity.this);
            linearLayoutManger.setOrientation(LinearLayoutManager.VERTICAL);
            CourseList.setLayoutManager(linearLayoutManger);
            courseAdapter = new CourseAdapter(Admin_coursePageActivity.this,AllCourse);
            CourseList.setAdapter(courseAdapter);



        });
        UpgradeCourseName.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                dbHandler = new CourseDBHelper(Admin_coursePageActivity.this);
                String courseCode = CourseCode.getText().toString();
                String courseName = CourseName.getText().toString();
                if (courseName.equals("") || courseCode.equals("")){
                    Toast.makeText(Admin_coursePageActivity.this,"You can't upgrade a course without nothing",Toast.LENGTH_SHORT).show();
                }else {
                Course course = new Course(courseCode,courseName);
                dbHandler.UpgradeName(course);
                Toast.makeText(Admin_coursePageActivity.this,"Upgrade Successfully",Toast.LENGTH_SHORT).show();
                }

            }
        });
        UpgradeCourseCode.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dbHandler = new CourseDBHelper(Admin_coursePageActivity.this);
                String courseCode = CourseCode.getText().toString();
                String courseName = CourseName.getText().toString();
                if (courseName.equals("") || courseCode.equals("")){
                    Toast.makeText(Admin_coursePageActivity.this,"You can't upgrade a course without nothing",Toast.LENGTH_SHORT).show();
                }else {
                Course course = new Course(courseCode,courseName);
                dbHandler.UpgradeCode(course);
                Toast.makeText(Admin_coursePageActivity.this,"Upgrade Successfully",Toast.LENGTH_SHORT).show();}
            }
        });













    }
}