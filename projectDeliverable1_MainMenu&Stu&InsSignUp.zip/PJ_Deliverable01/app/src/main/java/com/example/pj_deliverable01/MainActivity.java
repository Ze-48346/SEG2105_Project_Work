package com.example.pj_deliverable01;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import com.google.android.material.textfield.TextInputLayout;

public class MainActivity extends AppCompatActivity {
    Button btnLogIn,btnSignUP;
    TextView message;
    RadioGroup radioGroup;
    RadioButton radioButton;
    TextInputLayout textInputUser;
    TextInputLayout textInputPassWord;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnLogIn = (Button) findViewById(R.id.btnLogIn);
        btnSignUP = (Button) findViewById(R.id.btnSignUP);
        radioGroup = findViewById(R.id.rGroup);
        message = findViewById(R.id.message);
        textInputUser = findViewById(R.id.textInputUser);
        textInputPassWord = findViewById(R.id.textInputPassWord);


        btnLogIn.setOnClickListener( new View.OnClickListener(){
            @Override
            public void onClick(View v){
                int radioID = radioGroup.getCheckedRadioButtonId();
                radioButton = findViewById(radioID);
//                System.out.println("This is check:::::::::::::::::::::");
                if(radioButton.getText().equals("Administrator")){
                    if( validateUser() ) {
                        openAdministrator_Main_Page();
                    }
//                    System.out.println(validateUser());
//                    System.out.println("Successful");
                } else{
                    message.setText("Invalid Choice");
                }
            }
        });

        btnSignUP.setOnClickListener( new View.OnClickListener(){
            @Override
            public void onClick(View v){
                int radioID = radioGroup.getCheckedRadioButtonId();
                radioButton = findViewById(radioID);
                if(radioButton.getText().equals("Student")){
                    openStudent_SignUP();
                }
                if(radioButton.getText().equals("Instructor")){
                    openInstructor_SignUP();
                }
            }
        });

    }

    public boolean validateUser(){
        String userAccount = textInputUser.getEditText().getText().toString().trim();
        String userPassWord = textInputPassWord.getEditText().getText().toString().trim();
        boolean accountBoolean = userAccount.equals("admin");
        boolean passWordBoolean = userPassWord.equals("admin123");
//        System.out.println(userAccount);
//        System.out.println(userPassWord);
//        System.out.println(accountBoolean);
//        System.out.println(passWordBoolean);
        if(accountBoolean && passWordBoolean){
            return true;
        }  else {
            return false;
        }
    }

    public void openAdministrator_Main_Page(){
        Intent intent = new Intent(this,Administrator_Main_Page.class);
        startActivity(intent);
    }

    public void openStudent_SignUP(){
        Intent intent = new Intent(this,Student_SignUP.class);
        startActivity(intent);
    }

    public void openInstructor_SignUP(){
        Intent intent = new Intent(this,Instructor_SignUP.class);
        startActivity(intent);
    }



    public void checkButton(View v){
        int radioID = radioGroup.getCheckedRadioButtonId();
        radioButton = findViewById(radioID);
    }
}























