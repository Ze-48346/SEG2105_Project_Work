package com.example.pj_deliverable01;


import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class MyDBHandler extends SQLiteOpenHelper {
    private static final int DATABSE_VERSION = 1;
    private static final String DATABASE_NAME = "SEG2105_Project.db";

    private static final String TABLE_STUDENT = "Student";
    private static final String STUDENT_ID = "Student_ID";
    private static final String STUDENT_NAME = "Student_Name";
    private static final String STUDENT_PASSWORD = "Student_PassWord";


    private static final String TABLE_INSTRUCTOR = "Instructor";
    private static final String INSTRUCTOR_ID = "Instructor_ID";
    private static final String INSTRUCTOR_NAME = "Instructor_Name";
    private static final String INSTRUCTOR_PASSWORD = "Instructor_PassWord";


    public MyDBHandler(Context context){
        super(context, DATABASE_NAME,null,DATABSE_VERSION);
    }

    public void onCreate(SQLiteDatabase db){
        String TableStudent = "CREATE TABLE " + TABLE_STUDENT + "(" +
                STUDENT_ID + " INTEGER PRIMARY KEY," +
                STUDENT_NAME + " TEXT," +
                STUDENT_PASSWORD + " TEXT" + ")";

        String TableInstructor = "CREATE TABLE " + TABLE_INSTRUCTOR + "(" +
                INSTRUCTOR_ID + " INTEGER PRIMARY KEY," +
                INSTRUCTOR_NAME + " TEXT," +
                INSTRUCTOR_PASSWORD + " TEXT" + ")";

        db.execSQL(TableStudent);
        db.execSQL(TableInstructor);
    }

    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion){
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_STUDENT);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_INSTRUCTOR);
        onCreate(db);
    }

    public void addStudent(Student student){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues studentInfo = new ContentValues();
        studentInfo.put(STUDENT_ID, student.getID());
        studentInfo.put(STUDENT_NAME, student.getName());
        studentInfo.put(STUDENT_PASSWORD, student.getPassWord());
        db.insert(TABLE_STUDENT, null, studentInfo);
//        db.close();
    }


    public Student findStudent(String studentID){
        SQLiteDatabase db = this.getWritableDatabase();

        String query = "SELECT * FROM " + TABLE_STUDENT + " WHERE " + STUDENT_ID + " = \"" + studentID + "\"";
        Cursor cursor = db.rawQuery(query, null);

        Student student = new Student();
        if(cursor.moveToFirst()){
            student.setID(cursor.getString(0));
            student.setName(cursor.getString(1));
            student.setPassWord(cursor.getString(2));
        } else{
            student = null;
        }
//        db.close();
        return student;
    }

//    public boolean deleteProduct(String productName){
//        boolean result = false;
//        SQLiteDatabase db = this.getWritableDatabase();
//
//        String query = "SELECT * FROM " + TABLE_PRODUCTS + " WHERE  " + COLUMN_PRODUCTNAME + " = \""
//                + productName + "\"";
//        Cursor cursor = db.rawQuery(query,null);
//        if(cursor.moveToFirst()){
//            String idStr = cursor.getString(0);
//            db.delete(TABLE_PRODUCTS, COLUMN_ID + " = " + idStr,null);
//            cursor.close();
//            result =true;
//        }
//        return result;
//    }

    public void addInstructor(Instructor instructor){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues instructorInfo = new ContentValues();
        instructorInfo.put(INSTRUCTOR_ID, instructor.getID());
        instructorInfo.put(INSTRUCTOR_NAME, instructor.getName());
        instructorInfo.put(INSTRUCTOR_PASSWORD, instructor.getPassWord());
        db.insert(TABLE_INSTRUCTOR, null, instructorInfo);
//        db.close();
    }

    public Instructor findInstructor(String instructorID){
        SQLiteDatabase db = this.getWritableDatabase();

        String query = "SELECT * FROM " + TABLE_INSTRUCTOR + " WHERE " + INSTRUCTOR_ID + " = \"" + instructorID + "\"";
        Cursor cursor = db.rawQuery(query, null);

        Instructor instructor = new Instructor();
        if(cursor.moveToFirst()){
            instructor.setID(cursor.getString(0));
            instructor.setName(cursor.getString(1));
            instructor.setPassWord(cursor.getString(2));
        } else{
            instructor = null;
        }
//        db.close();
        return instructor;
    }

}

