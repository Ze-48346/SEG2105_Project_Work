package com.example.pj_deliverable01;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class Administrator_Main_Page extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_administrator_main_page);
    }
}