package com.example.pj_deliverable01;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

public class Student_MainMenu extends AppCompatActivity {

    private TextView tvWelcomeText;
    private String student_name;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_student_main_menu);

        tvWelcomeText = findViewById(R.id.tvStuWelcomeText);
        student_name = getIntent().getStringExtra("studentName");
        tvWelcomeText.setText("Welcome Student " + student_name + "!");
    }
}