package com.example.pj_deliverable01;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class MyDBHandler extends SQLiteOpenHelper {
    private static final int DATABSE_VERSION = 1;
    private static final String DATABASE_NAME = "SEG2105_Project.db";

    // Student //
    private static final String TABLE_STUDENT = "Student";
    private static final String STUDENT_ID = "Student_ID";
    private static final String STUDENT_NAME = "Student_Name";
    private static final String STUDENT_PASSWORD = "Student_PassWord";
    // Student //


    public MyDBHandler(Context context){
        super(context, DATABASE_NAME,null,DATABSE_VERSION);
    }

    public void onCreate(SQLiteDatabase db){
        String TableStudent = "CREATE TABLE " + TABLE_STUDENT + "(" +
                STUDENT_ID + " TEXT PRIMARY KEY," +
                STUDENT_NAME + " TEXT," +
                STUDENT_PASSWORD + " TEXT" + ")";


        db.execSQL(TableStudent);
    }

    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion){
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_STUDENT);
        onCreate(db);
    }

    public void addStudent(Student student){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues studentInfo = new ContentValues();
        studentInfo.put(STUDENT_ID, student.getID());
        studentInfo.put(STUDENT_NAME, student.getName());
        studentInfo.put(STUDENT_PASSWORD, student.getPassWord());
        db.insert(TABLE_STUDENT, null, studentInfo);
//        db.close();
    }


    // Student------------------------------------ //
    public Student findStudent(String studentID){
        SQLiteDatabase db = this.getWritableDatabase();

        String query = "SELECT * FROM " + TABLE_STUDENT + " WHERE " + STUDENT_ID + " = \"" + studentID + "\"";
        Cursor cursor = db.rawQuery(query, null);

        Student student = new Student();
        if(cursor.moveToFirst()){
            student.setID(cursor.getString(0));
            student.setName(cursor.getString(1));
            student.setPassWord(cursor.getString(2));
        } else{
            student = null;
        }
//        db.close();
        return student;
    }

    public ArrayList<Student>  findAllStudent(){
        SQLiteDatabase db = this.getWritableDatabase();
        ArrayList<Student> allStudentList = new ArrayList<Student>();

        String query = "SELECT * FROM " + TABLE_STUDENT;
        Cursor cursor = db.rawQuery(query, null);


        while(cursor.moveToNext()){
            Student student = new Student();
            student.setID(cursor.getString(0));
            student.setName(cursor.getString(1));
            student.setPassWord(cursor.getString(2));
            allStudentList.add(student);
        }
//        db.close();
        return allStudentList;
    }

    public boolean deleteStudent(String studentID){
        boolean result = false;
        SQLiteDatabase db = this.getWritableDatabase();

        String query = "SELECT * FROM " + TABLE_STUDENT + " WHERE  " + STUDENT_ID + " = \""
                + studentID + "\"";
        Cursor cursor = db.rawQuery(query,null);
        if(cursor.moveToFirst()){
            String idStr = cursor.getString(0);
            db.delete(TABLE_STUDENT, STUDENT_ID + " = " + idStr,null);
            cursor.close();
            result =true;
        }
        return result;
    }
    // Student------------------------------------ //

    // Course------------------------------------ //
}

