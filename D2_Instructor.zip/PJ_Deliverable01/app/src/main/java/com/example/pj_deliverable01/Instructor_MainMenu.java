package com.example.pj_deliverable01;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;


public class Instructor_MainMenu extends AppCompatActivity {
    private TextView tvWelcomeText;
    private String instructor_name;
    private Button btnOpCourse;
    private Button btnBack;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_instructor_main_menu);

        tvWelcomeText = findViewById(R.id.tvInsWelcomeText);
        instructor_name = getIntent().getStringExtra("instructorName");
        tvWelcomeText.setText("Welcome Instructor " + instructor_name + "!");
        btnOpCourse = (Button) findViewById(R.id.btnCourseOp);
        btnBack = (Button) findViewById(R.id.btnBack_Main);

        btnOpCourse.setOnClickListener( new View.OnClickListener(){
            @Override
            public void onClick(View v){
                openInstructor_OperationOnCourse();
            }
        });
        btnBack.setOnClickListener( new View.OnClickListener(){
            @Override
            public void onClick(View v){
                backToMainActivity();
            }
        });
    }

    public void openInstructor_OperationOnCourse(){
        Intent intent = new Intent(this,Instructor_coursePageActivity.class);
        startActivity(intent);
    }
    private void backToMainActivity(){
        Intent intent = new Intent(this,MainActivity.class);
        startActivity(intent);
    }
}