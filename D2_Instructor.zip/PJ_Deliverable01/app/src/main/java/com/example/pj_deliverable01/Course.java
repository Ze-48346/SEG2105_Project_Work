package com.example.pj_deliverable01;

public class Course {
    private String _CourseCode;
    private String _CourseName;
    private int _ID;
    private String _InstructorID;
    private String _InstructorName;
    private String _Days;
    private String _Hours;
    private String _Description;
    private int _Capacity;

    public Course(){
    }
    public Course(String CourseCode, String CourseName){
        _CourseCode = CourseCode;
        _CourseName = CourseName;

    }
    public Course(int ID, String CourseCode,String CourseName){
        _ID = ID;
        _CourseCode=CourseCode;
        _CourseCode=CourseName;
    }
    public Course(String CourseCode,String CourseName,String InstructorID) {
        _CourseCode = CourseCode;
        _CourseName = CourseName;
        _InstructorID = InstructorID;
    }
    public Course(String CourseCode,String CourseName,String InstructorName, String InstructorID) {
        _CourseCode = CourseCode;
        _CourseName = CourseName;
        _InstructorID = InstructorID;
        _InstructorName = InstructorName;
    }
    public Course(String CourseCode,String days,String hours, String description, int capacity) {
        _CourseCode = CourseCode;
        _Days = days;
        _Hours = hours;
        _Description = description;
        _Capacity = capacity;
    }
    public  void  set_ID(int ID){_ID= ID;}
    public  int get_ID(int ID){return ID;}
    public void set_CourseCode(String CourseCode){
        _CourseCode= CourseCode;
    }
    public String get_CourseCode(){
        return _CourseCode;
    }
    public void  set_CourseName(String CourseName){
        _CourseName=CourseName;
    }
    public String get_CourseName(){
        return _CourseName;
    }
    public void set_InstructorID(String InstructorID) { _InstructorID=InstructorID; }
    public String get_InstructorID() { return _InstructorID; }
    public void set_InstructorName(String InstructorName) { _InstructorName=InstructorName; }
    public String get_InstructorName() { return _InstructorName; }
    public void set_Days(String Days) { _Days=Days; }
    public String get_Days() { return _Days; }
    public void set_Hours(String Hours) { _Hours=Hours; }
    public String get_Hours() { return _Hours; }
    public void set_Description(String Description) { _Description=Description; }
    public String get_Description() { return _Description; }
    public void set_Capacity(int Capacity) { _Capacity=Capacity; }
    public int get_Capacity() { return _Capacity; }

}
