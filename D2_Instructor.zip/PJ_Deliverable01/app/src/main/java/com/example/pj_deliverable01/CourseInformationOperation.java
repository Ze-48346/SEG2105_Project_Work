package com.example.pj_deliverable01;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.List;

public class CourseInformationOperation extends AppCompatActivity{
    private EditText Days;
    private EditText Hours;
    private EditText Description;
    private EditText Capacity;
    private EditText CourseCode;
    private Button addAll;
    private Button btnBack;
    private Button btnHideKeyboard;
    private MyDBHandler dbHandler;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.instructor_add_information);

        CourseCode = findViewById(R.id.CourseCode);
        Days = findViewById(R.id.Days);
        Hours = findViewById(R.id.Hours);
        Description = findViewById(R.id.Description);
        Capacity = findViewById(R.id.Capacity);
        addAll = findViewById(R.id.add);
        btnBack = findViewById(R.id.btnBack);
        btnHideKeyboard = findViewById(R.id.btnHideKeyboard);
        dbHandler = new MyDBHandler(CourseInformationOperation.this);

        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                backToMainActivity();
            }
        });

        btnHideKeyboard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                closeKeyboard();
            }
        });

        addAll.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dbHandler = new MyDBHandler(CourseInformationOperation.this);
                String courseCode = CourseCode.getText().toString();
                String days = Days.getText().toString();
                String hours = Hours.getText().toString();
                String description = Description.getText().toString();
                String capacityS = Capacity.getText().toString();
                int capacity;

                if (courseCode.equals("") || days.equals("") || hours.equals("") || description.equals("") || capacityS.equals("")) {
                    Toast.makeText(CourseInformationOperation.this, "Nothing to add", Toast.LENGTH_SHORT).show();
                } else {
                    capacity = Integer.parseInt(capacityS);
                    Course course = new Course(courseCode, days, hours, description, capacity);
                    dbHandler.AddCourseInformation(course);
                    Toast.makeText(CourseInformationOperation.this, "Add Successfully", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    private void closeKeyboard(){
        View view = this.getCurrentFocus();
        if(view != null){
            InputMethodManager imm = (InputMethodManager)getSystemService(Context.INPUT_METHOD_SERVICE);
            imm.hideSoftInputFromWindow(view.getWindowToken(),0);
        }
    }

    private void backToMainActivity(){
        Intent intent = new Intent(this,Instructor_coursePageActivity.class);
        startActivity(intent);
    }

}
